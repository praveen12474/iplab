import java.io.IOException;

import java.io.PrintWriter;

import java.util.HashMap;

import java.util.Map;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

@WebServlet("/Servlet1")

public class Servlet1 extends HttpServlet {


// A simple in-memory map to track submission counts across sessions by name

private static final Map<String, Integer> nameCountMap = new HashMap<>();


protected void doPost(HttpServletRequest request, HttpServletResponse response)

throws ServletException, IOException {


response.setContentType("text/html");

PrintWriter out = response.getWriter();


String name = request.getParameter("name");

String age = request.getParameter("age");

String gender = request.getParameter("gender");

String department = request.getParameter("department");

String year = request.getParameter("year");

String email = request.getParameter("email");

String city = request.getParameter("city");

HttpSession session = request.getSession();

synchronized (nameCountMap) {

int count = nameCountMap.getOrDefault(name, 0) + 1;

nameCountMap.put(name, count);

// Store the count in the session so Servlet3 can retrieve it

session.setAttribute("submissionCount", count);

}

out.println("<html>");

out.println("<body>");

out.println("<h2>Welcome, " + name + "</h2>");

out.println("<p>Choose a Session Tracking Method:</p>");


// 1. Hidden Form Field (Points to Servlet3)

out.println("<form action='Servlet3' method='post'>");

out.println("<input type='hidden' name='name' value='" + name + "'>");

out.println("<input type='hidden' name='age' value='" + age + "'>");

out.println("<input type='hidden' name='gender' value='" + gender + "'>");

out.println("<input type='hidden' name='department' value='" + department + "'>");

out.println("<input type='hidden' name='year' value='" + year + "'>");

out.println("<input type='hidden' name='email' value='" + email + "'>");

out.println("<input type='hidden' name='city' value='" + city + "'>");

out.println("<input type='submit' value='Visit using Hidden Fields'>");

out.println("</form>");

out.println("<br>");


// 2. URL Rewriting (Points to Servlet3 via GET request)

out.println("<a href='Servlet3"

+ "?name=" + name

+ "&age=" + age

+ "&gender=" + gender

+ "&department=" + department

+ "&year=" + year

+ "&email=" + email

+ "&city=" + city

+ "'>");

out.println("Visit using URL Rewriting");

out.println("</a>");

out.println("</body>");

out.println("</html>");

}

}