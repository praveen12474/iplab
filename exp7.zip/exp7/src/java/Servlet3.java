import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

@WebServlet("/Servlet3")

public class Servlet3 extends HttpServlet {

protected void doPost(HttpServletRequest request, HttpServletResponse response)

throws ServletException, IOException {

displayDetails(request, response);

}

protected void doGet(HttpServletRequest request, HttpServletResponse response)

throws ServletException, IOException {

displayDetails(request, response);

}

private void displayDetails(HttpServletRequest request, HttpServletResponse response)

throws IOException {

response.setContentType("text/html");

PrintWriter out = response.getWriter();

String name = request.getParameter("name");

String age = request.getParameter("age");

String gender = request.getParameter("gender");

String department = request.getParameter("department");

String year = request.getParameter("year");

String email = request.getParameter("email");

String city = request.getParameter("city");

// Retrieve submission count from session

HttpSession session = request.getSession(false);

int count = 1;

if (session != null && session.getAttribute("submissionCount") != null) {

count = (int) session.getAttribute("submissionCount");

}

out.println("<html>");

out.println("<body>");

out.println("<h2>Student Details</h2>");

out.println("Name: " + name + "<br><br>");

out.println("Age: " + age + "<br><br>");

out.println("Gender: " + gender + "<br><br>");

out.println("Department: " + department + "<br><br>");

out.println("Year: " + year + "<br><br>");

out.println("Email: " + email + "<br><br>");

out.println("City: " + city + "<br><br>");

// Display the submission count

out.println("<h3>Submission Count for " + name + ": " + count + "</h3>");

out.println("<h3>Session Tracking Successful!</h3>");

out.println("</body>");

out.println("</html>");

}

}