<!DOCTYPE html>
<html>

<head>
    <title>Library Book Details</title>
</head>

<body>

<h1>Library Book Details</h1>

<?php

$xml = simplexml_load_file("books.xml")
       or die("Error: Cannot load XML file.");

echo "<table border='1' cellpadding='10' cellspacing='0'>";

echo "<tr>";
echo "<th>Title</th>";
echo "<th>Author</th>";
echo "<th>Year</th>";
echo "<th>Genre</th>";
echo "<th>Publisher</th>";
echo "<th>Pages</th>";
echo "<th>Rating</th>";
echo "<th>Price</th>";
echo "</tr>";

foreach ($xml->book as $book) {

    echo "<tr>";

    echo "<td>" . $book->title . "</td>";
    echo "<td>" . $book->author . "</td>";
    echo "<td>" . $book->year . "</td>";
    echo "<td>" . $book->genre . "</td>";
    echo "<td>" . $book->publisher . "</td>";
    echo "<td>" . $book->pages . "</td>";
    echo "<td>" . $book->rating . "</td>";
    echo "<td>₹" . $book->price . "</td>";

    echo "</tr>";
}

echo "</table>";

?>

</body>

</html>