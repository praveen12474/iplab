<?php
// 1. Connect to MySQL (Fixed 'mysql' to 'mysqli')
$conn = new mysqli("localhost", "root", "mysql", "shopping_db");

// 2. Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. INSERT data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $customer_name = trim($_POST["customer_name"]);
    $product_name = trim($_POST["product_name"]);
    $quantity = intval($_POST["quantity"]);
    $total_price = floatval($_POST["total_price"]);

    $sql = "INSERT INTO orders (customer_name, product_name, quantity, total_price) VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssid", $customer_name, $product_name, $quantity, $total_price);

    if ($stmt->execute()) {
        echo "<p style='color:green;'>Order placed successfully!</p>";
    } else {
        echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

// 4. SELECT data
$sql = "SELECT * FROM orders ORDER BY order_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<title>Online Shopping Application</title>
</head>
<body>

<h2>Place Your Order</h2>

<!-- Form submits to the same page -->
<form method="POST" action="">
    Customer Name: <input type="text" name="customer_name" required> <br><br>
    Product Name: <input type="text" name="product_name" required> <br><br>
    Quantity: <input type="number" name="quantity" min="1" required> <br><br>
    Total Price ($): <input type="number" step="0.01" name="total_price" required> <br><br>
    <input type="submit" value="Submit Order">
</form>

<hr>

<h2>Stored Order Details</h2>

<table border="1" cellpadding="10">
<tr>
    <th>Order ID</th>
    <th>Customer Name</th>
    <th>Product Name</th>
    <th>Quantity</th>
    <th>Total Price</th>
    <th>Order Date</th>
</tr>

<?php
// 5. Display records
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["customer_name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["product_name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["quantity"]) . "</td>";
        echo "<td>$" . htmlspecialchars(number_format($row["total_price"], 2)) . "</td>";
        echo "<td>" . htmlspecialchars($row["order_date"]) . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr>";
    echo "<td colspan='6'>No orders found</td>";
    echo "</tr>";
}

// 6. Close the connection
$conn->close();
?>

</table>

</body>
</html>