<!DOCTYPE html>
<html>
<head>
<title>Online Shopping - Place Order</title>
</head>
<body>

<h2>Place Your Order</h2>

<!-- Form -->
<form method="POST" action="order.php">

Customer Name:
<input type="text" name="customer_name" required> <br><br>

Product Name:
<input type="text" name="product_name" required> <br><br>

Quantity:
<input type="number" name="quantity" min="1" required> <br><br>

Total Price ($):
<input type="number" step="0.01" name="total_price" required> <br><br>

<input type="submit" value="Submit Order">

</form>

</body>
</html>