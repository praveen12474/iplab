import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ExamServlet")
public class ExamServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve student details
        String username = request.getParameter("username");
        String rollno = request.getParameter("rollno");
        String studentClass = request.getParameter("student_class");

        // Define correct answers mapping
        Map<String, String> correctAnswers = new HashMap<>();
        correctAnswers.put("q1", "paris");
        correctAnswers.put("q2", "4");
        correctAnswers.put("q3", "Mountain");
        correctAnswers.put("q4", "41");
        correctAnswers.put("q5", "Modi");
        correctAnswers.put("q6", "Netbeans");
        correctAnswers.put("q7", "null");
        correctAnswers.put("q8", "Both a & b");
        correctAnswers.put("q9", "Const");
        correctAnswers.put("q10", "32");

        // Define question marks
        Map<String, Integer> questionMarks = new HashMap<>();
        questionMarks.put("q1", 1);
        questionMarks.put("q2", 1); // Fill in the blank (1 Mark)
        questionMarks.put("q3", 1);
        questionMarks.put("q4", 2); // Fill in the blank (2 Marks)
        questionMarks.put("q5", 1);
        questionMarks.put("q6", 1);
        questionMarks.put("q7", 1);
        questionMarks.put("q8", 2);
        questionMarks.put("q9", 1);
        questionMarks.put("q10", 2); // Fill in the blank (2 Marks)

        int totalScore = 0;
        int maxTotalMarks = 13; 

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Exam Results</title>");
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; margin: 30px; background-color: #f4f4f4; }");
        out.println(".container { background-color: white; padding: 25px; border-radius: 10px; max-width: 800px; margin: auto; }");
        out.println("h1 { text-align: center; color: #333; }");
        out.println(".correct { color: green; font-weight: bold; }");
        out.println(".incorrect { color: red; font-weight: bold; }");
        out.println("</style></head><body>");
        out.println("<div class=\"container\">");
        out.println("<h1>Exam Evaluation Report</h1><hr>");
        out.println("<p><strong>Name:</strong> " + username + "</p>");
        out.println("<p><strong>Roll No:</strong> " + rollno + "</p>");
        out.println("<p><strong>Class:</strong> " + studentClass + "</p>");
        out.println("<hr><ul>");

        for (int i = 1; i <= 10; i++) {
            String qKey = "q" + i;
            String userAns = request.getParameter(qKey);
            String correctAns = correctAnswers.get(qKey);
            int marks = questionMarks.get(qKey);
            
            boolean isCorrect = false;
            if (userAns != null) {
                // Use case-insensitive trim check for fill-in-the-blank questions (q2, q4, q10)
                if (qKey.equals("q2") || qKey.equals("q4") || qKey.equals("q10")) {
                    isCorrect = userAns.trim().equalsIgnoreCase(correctAns);
                } else {
                    isCorrect = userAns.equals(correctAns);
                }
            }

            if (isCorrect) {
                totalScore += marks;
            }

            out.println("<li style=\"margin-bottom: 10px;\">");
            out.println("<strong>Question " + i + " (" + marks + " Mark" + (marks > 1 ? "s" : "") + "):</strong> Your Answer: ");
            out.println("<span class=\"" + (isCorrect ? "correct" : "incorrect") + "\">" + (userAns != null && !userAns.trim().isEmpty() ? userAns : "No Answer") + "</span>");
            if (!isCorrect) {
                out.println("<br><small style=\"color: gray;\">Correct Answer: " + correctAns + "</small>");
            }
            out.println("</li>");
        }

        out.println("</ul><hr>");
        out.println("<h2>Final Score: " + totalScore + " / " + maxTotalMarks + "</h2>");
        out.println("</div></body></html>");
    }
}